﻿using System;

namespace HelloWorld
{
    /// <summary>
    /// Entry point of App
    /// </summary>
    class Program
    {
        /// <summary>
        /// Main mentod
        /// </summary>
        /// <param name="args"> argument</param>
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

           int result= Add(1, 2);
            int subResult = Subtract(10, 2);

           string conCat=Add("Indra", "nil");

            double w = 1.45255;
            char charVariable = 'c';
            string str = "Multiple Character";

            /*
             * Entry point of your Application
             * .NET Core Application
             * 
             * .NET Framework
             * For Windows App  & Console App
             * Program.cs -> Main method
             * 
             * Web Application
             * Global.asax
             * Application_Start()
             */
        }

        static int Add (int num1, int num2)
        {
            return num1 + num2;
        }
        static string Add(string s1, string s2)
        {
            return s2 + s2;
        }

        static int Subtract(int num1, int num2)
        {
            return num1 - num2;
        }
    }
}
